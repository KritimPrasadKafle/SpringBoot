package com.spring.demo;


public class Employee{
    private int reg;
    private String name;
    private int Family;

    public Employee(int reg, String name, int family) {
        this.reg = reg;
        this.name = name;
        Family = family;
    }

    public int getReg() {
        return reg;
    }

    public void setReg(int reg) {
        this.reg = reg;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getFamily() {
        return Family;
    }

    public void setFamily(int family) {
        Family = family;
    }
}
