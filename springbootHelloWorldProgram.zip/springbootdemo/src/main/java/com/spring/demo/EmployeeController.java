package com.spring.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class EmployeeController {

    @GetMapping("/employee")
    public Employee getEmployee(){
        return new Employee(1,"Hello ME",4);
    }

    @GetMapping("/employees")
    public List<Employee> getEmployees(){
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(3,"Kritim",5));
        employees.add(new Employee(2,"Kafle",7));
        employees.add(new Employee(4,"Krisha",8));

        return employees;
    }

}
