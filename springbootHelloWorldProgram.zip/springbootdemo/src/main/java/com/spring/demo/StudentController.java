package com.spring.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class StudentController {
    @GetMapping("/student")
    public Student getStudent(){



        return new Student(10, "Kritim", "Kafle");
    }

    @GetMapping("/students")

    public List<Student> getStudents(){
        List<Student> students = new ArrayList<>();
        students.add(new Student(1, "Kri","kaf"));
        students.add(new Student(4, "Krit","kafl"));
        students.add(new Student(7, "Kriti","kafle"));
        students.add(new Student(6, "Krim","kafe"));
        students.add(new Student(8, "Krii","kafee"));
        return students;

    }
}
